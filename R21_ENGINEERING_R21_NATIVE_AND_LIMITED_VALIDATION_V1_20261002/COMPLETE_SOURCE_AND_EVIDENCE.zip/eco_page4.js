const d={"project": "a8676ecc06b5399826a37ec617e3c862b83d70e446d12d7b9a2a7b02796fcd50", "page": {"uuid": "52a8a60e5711e55b", "index": 4, "name": "MCU_Protected_Interfaces"}, "added": [], "reset": {"ref": "R_J3_5", "device": "0603WAF1001T5E", "device_uuid": "18db11499a04403ba8c98e2f7a687fbc", "library_uuid": "0819f05c4eef4c71ace90d822a990e87", "page": 4, "x": 280, "y": 1040, "rotation": 0, "subpart": "0603WAF1001T5E.1", "nets": {"1": "MCU_NRST_EXT", "2": "PGOOD"}, "value": "1k 1%", "role": "Direct external OD/OC reset, VOL<=0.4V, release HiZ; no push-pull high"}, "notes": ["R2.1 ENGINEERING REVIEW - MCU_Protected_Interfaces - 5/6", "J3.5 external NRST ->1k ->PGOOD/MCU_NRST; OD/OC VOL<=0.4V, releaseHiZ.", "Other interfaces retain4.99k/clamps;3V3 sense is not an external power input.", "32offline protocol regressions;9.6ms state schedule; realWCET pending."]};
const pr=await eda.dmt_Project.getCurrentProjectInfo();if(pr.uuid!==d.project)throw Error('Wrong workcopy');
await eda.dmt_EditorControl.openDocument(d.page.uuid);
const result={page:d.page,changes:[]};
const all=await eda.sch_PrimitiveComponent.getAll();
function close(a,b){return Math.abs(a-b)<1e-5;}
async function pinWire(pin){
 const x=pin.getState_X(),y=pin.getState_Y();const found=[];
 for(const w of await eda.sch_PrimitiveWire.getAll()){
 const raw=w.getState_Line();for(const line of (Array.isArray(raw[0])?raw:[raw])){
  if(close(line[0],x)&&close(line[1],y))found.push({wire:w,line,far:[line.at(-2),line.at(-1)]});
  else if(close(line.at(-2),x)&&close(line.at(-1),y))found.push({wire:w,line,far:[line[0],line[1]]});
 }
 }
 if(found.length!==1)throw Error('Expected one existing pin stub');return found[0];
}
async function add(q){
 let c=await eda.sch_PrimitiveComponent.create({libraryUuid:q.library_uuid,uuid:q.device_uuid},q.x,q.y,q.subpart,0,false,true,true);
 if(!c)throw Error('Create '+q.ref);
 let pins=await eda.sch_PrimitiveComponent.getAllPinsByPrimitiveId(c.getState_PrimitiveId());
 if(pins.length!==2)throw Error('New passive pin count');
 if(close(pins[0].getState_X(),pins[1].getState_X())){c=await eda.sch_PrimitiveComponent.modify(c,{rotation:90});pins=await eda.sch_PrimitiveComponent.getAllPinsByPrimitiveId(c.getState_PrimitiveId());}
 if(!close(pins[0].getState_Y(),pins[1].getState_Y()))throw Error('Passive must be horizontal');
 c=await eda.sch_PrimitiveComponent.modify(c,{designator:q.ref,name:q.value,otherProperty:{...c.getState_OtherProperty(),Value:q.value,'Circuit Role':q.role,'Review Status':'R2.1 engineering review; BENCH_PENDING'}});
 for(const pin of pins){const number=String(pin.getState_PinNumber()),net=q.nets[number];if(!net)throw Error('New pin net');
  const x=pin.getState_X(),y=pin.getState_Y(),ex=x+(x<q.x?-55:55);
  const port=await eda.sch_PrimitiveComponent.createNetPort('BI',net,ex,y,ex<x?180:0,false);if(!port)throw Error('New port');
  const anchor=(await eda.sch_PrimitiveComponent.getAllPinsByPrimitiveId(port.getState_PrimitiveId()))[0];
  if(!close(anchor.getState_X(),ex)||!close(anchor.getState_Y(),y))throw Error('Port anchor mismatch');
  if(!await eda.sch_PrimitiveWire.create([[x,y,ex,y]],net))throw Error('New wire');
 }
 result.changes.push({ref:q.ref,action:'created',association:c.getState_Component(),footprint:c.getState_Footprint()});return c;
}
if(d.page.index===0){
 const c=all.find(x=>x.getState_Designator()==='U3'&&x.getState_ComponentType()==='part');if(!c)throw Error('Missing U3');
 for(const [number,net] of [['2','VCM_FB'],['6','VEXC_FB']]){
  const pin=(await eda.sch_PrimitiveComponent.getAllPinsByPrimitiveId(c.getState_PrimitiveId())).find(p=>String(p.getState_PinNumber())===number);const stub=await pinWire(pin);
  const ports=[];for(const p of all)if(p.getState_ComponentType()==='netport'){
   const pp=(await eda.sch_PrimitiveComponent.getAllPinsByPrimitiveId(p.getState_PrimitiveId()))[0];if(close(pp.getState_X(),stub.far[0])&&close(pp.getState_Y(),stub.far[1]))ports.push(p);
  }
  if(ports.length!==1)throw Error('Feedback port identity');await ports[0].setState_Net(net).done();await stub.wire.setState_Net(net).done();result.changes.push({ref:'U3',pin:number,net});
 }
}
if(d.page.index===4){
 const old=all.find(x=>x.getState_Designator()==='R_J3_5'&&x.getState_ComponentType()==='part');if(!old)throw Error('Missing reset resistor');
 const q=d.reset;const stubs={};for(const p of await eda.sch_PrimitiveComponent.getAllPinsByPrimitiveId(old.getState_PrimitiveId()))stubs[String(p.getState_PinNumber())]=await pinWire(p);
 if(!await eda.sch_PrimitiveComponent.delete(old))throw Error('Remove old4k99 reset');
 let c=await eda.sch_PrimitiveComponent.create({libraryUuid:q.library_uuid,uuid:q.device_uuid},q.x,q.y,q.subpart,0,false,true,true);
 c=await eda.sch_PrimitiveComponent.modify(c,{designator:q.ref,name:q.value,otherProperty:{...c.getState_OtherProperty(),Value:q.value,'Circuit Role':q.role}});
 for(const p of await eda.sch_PrimitiveComponent.getAllPinsByPrimitiveId(c.getState_PrimitiveId())){const stub=stubs[String(p.getState_PinNumber())];if(!stub)throw Error('Reset pin mismatch');const x=p.getState_X(),y=p.getState_Y(),[fx,fy]=stub.far;const line=close(y,fy)?[x,y,fx,fy]:[x,y,fx,y,fx,fy];if(!await eda.sch_PrimitiveWire.modify(stub.wire,{line:[line]}))throw Error('Reset stub edit');}
 result.changes.push({ref:q.ref,action:'physical device4k99->1k',association:c.getState_Component(),footprint:c.getState_Footprint()});
}
for(const q of d.added){if(all.some(x=>x.getState_Designator()===q.ref))throw Error('Duplicate new ref');await add(q);}
if(d.page.index===2)for(const c of all)if(/^C_ADC[0-3]$/.test(c.getState_Designator())){await eda.sch_PrimitiveComponent.modify(c,{name:'10nF X7R',otherProperty:{...c.getState_OtherProperty(),Value:'10nF X7R'}});result.changes.push({ref:c.getState_Designator(),action:'repair native Value'});}
// Move net names outside port outlines; keep every port, pin number and electrical stub.
let ports=0,wires=0;
for(const c of await eda.sch_PrimitiveComponent.getAll())if(c.getState_ComponentType()==='netport'){
 const pin=(await eda.sch_PrimitiveComponent.getAllPinsByPrimitiveId(c.getState_PrimitiveId()))[0];const left=c.getState_Rotation()===180;
 for(const a of await eda.sch_PrimitiveAttribute.getAll(c.getState_PrimitiveId()))if(a.getState_Key()==='Name')await eda.sch_PrimitiveAttribute.modify(a.getState_PrimitiveId(),{valueVisible:true,keyVisible:false,fontSize:8,rotation:0,x:pin.getState_X()+(left?-45:45),y:pin.getState_Y(),alignMode:left?8:2});ports++;
}
for(const w of await eda.sch_PrimitiveWire.getAll())for(const a of await eda.sch_PrimitiveAttribute.getAll(w.getState_PrimitiveId()))if(a.getState_Key()==='Name'){await eda.sch_PrimitiveAttribute.modify(a.getState_PrimitiveId(),{valueVisible:false,keyVisible:false});wires++;}
const texts=await eda.sch_PrimitiveText.getAll();const sorted=texts.sort((a,b)=>a.getState_Y()-b.getState_Y());
if(sorted.length!==4)throw Error('Expected four existing page notes');
for(let i=0;i<4;i++)await eda.sch_PrimitiveText.modify(sorted[i],{content:d.notes[i]});
result.layout={ports,wires,notes:4};result.saved=await eda.sch_Document.save();if(result.saved!==true)throw Error('Save failed');return result;
